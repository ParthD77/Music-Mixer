import java.awt.*;


// NOT GONNA DO RIGHT NOW, SEEMS TO USELESS
public class SmartPanel {
    private int x, y, width, height;
    private Color c;


    public SmartPanel(int x, int y, int width, int height, Color c){
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.c = c;
    }



    public void setColor(Color c) {
    }
    public static void main(String[] args) {

    }
}
